import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { cn } from '@/src/lib/utils';

export const Hero: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springX = useSpring(mouseX, { stiffness: 100, damping: 30 });
  const springY = useSpring(mouseY, { stiffness: 100, damping: 30 });

  const rotateX = useTransform(springY, [-0.5, 0.5], [10, -10]);
  const rotateY = useTransform(springX, [-0.5, 0.5], [-10, 10]);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const { left, top, width, height } = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - left) / width - 0.5;
    const y = (e.clientY - top) / height - 0.5;
    mouseX.set(x);
    mouseY.set(y);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  return (
    <section 
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative min-h-screen w-full flex items-center justify-center pt-24 pb-32 overflow-hidden bg-pop-white"
    >
      {/* Background Pop Art Elements */}
      <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-pop-red rounded-full opacity-10 animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-pop-yellow rounded-full opacity-20" />

      {/* Floating Text Left */}
      <motion.div
        animate={{ y: [0, -10, 0] }}
        transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
        className="absolute left-[5%] top-1/4 z-30 pointer-events-none"
      >
        <span className="block px-6 py-3 bg-white brutal-border pop-shadow text-pop-black font-display font-black text-xl md:text-2xl rotate-[-5deg]">
          Hello, I am Sanjay
        </span>
      </motion.div>

      {/* Floating Text Right */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 5, ease: "easeInOut", delay: 1 }}
        className="absolute right-[5%] bottom-1/4 z-30 pointer-events-none"
      >
        <span className="block px-6 py-3 bg-pop-red brutal-border pop-shadow text-white font-display font-black text-xl md:text-2xl rotate-[3deg]">
          Crafting Visual Stories
        </span>
      </motion.div>

      {/* Character Image Container */}
      <motion.div
        initial={{ y: '100%', opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1.2, ease: "easeOut", delay: 1.2 }}
        style={{ rotateX, rotateY, perspective: 1000 }}
        className="relative z-10"
      >
        <div className="relative w-[320px] h-[320px] md:w-[480px] md:h-[480px] rounded-full bg-pop-yellow brutal-border flex items-end justify-center overflow-hidden">
            {/* Pop-art overlay tint */}
            <div className="absolute inset-0 bg-pop-red mix-blend-multiply opacity-5 pointer-events-none" />
            
            <img 
              src="profile.webp" 
              alt="Sanjay Sahu"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover z-10"
            />

            {/* Black base shape */}
            <div className="absolute bottom-0 w-full h-1/3 bg-pop-black" />
            <div className="absolute bottom-6 z-20 text-white font-display font-black text-5xl italic tracking-tighter opacity-10">SANJAY</div>
        </div>
      </motion.div>

      {/* Hero Content Bottom */}
      <div className="absolute bottom-12 left-0 w-full flex flex-col items-center">
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="flex flex-col items-center gap-2"
        >
          <span className="font-mono text-xs tracking-widest opacity-50">SCROLL TO EXPLORE</span>
          <div className="w-px h-12 bg-pop-black opacity-20" />
        </motion.div>
      </div>
    </section>
  );
};
