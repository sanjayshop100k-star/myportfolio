import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface PreloaderProps {
  onComplete: () => void;
}

export const Preloader: React.FC<PreloaderProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => setIsFinished(true), 500);
          return 100;
        }
        return prev + Math.floor(Math.random() * 5) + 2;
      });
    }, 100);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (isFinished) {
      const finishTimer = setTimeout(() => {
        onComplete();
      }, 1000);
      return () => clearTimeout(finishTimer);
    }
  }, [isFinished, onComplete]);

  return (
    <AnimatePresence>
      {!isFinished && (
        <motion.div
          initial={{ y: 0 }}
          exit={{ y: '-100%' }}
          transition={{ duration: 1.2, ease: [0.76, 0, 0.24, 1] }}
          className="fixed inset-0 z-[10000] flex flex-col items-center justify-center bg-pop-white overflow-hidden"
        >
          {/* Kinetic Typography Background */}
          <div className="absolute inset-0 flex flex-col justify-center pointer-events-none">
            <motion.div
              animate={{ x: [0, -2000] }}
              transition={{ repeat: Infinity, duration: 20, ease: 'linear' }}
              className="marquee-text font-display"
            >
              DIGITAL CREATOR // VIDEO EDITOR // STRATEGIST //&nbsp;
              DIGITAL CREATOR // VIDEO EDITOR // STRATEGIST //&nbsp;
            </motion.div>
          </div>

          <div className="relative z-10 flex flex-col items-center">
            {/* Progress Bar */}
            <div className="w-80 h-10 bg-pop-black rounded-full p-1 mb-6 relative flex items-center justify-center overflow-hidden brutal-border shadow-2xl">
               <motion.div 
                animate={{ width: `${progress}%` }}
                className="absolute left-0 top-0 h-full bg-pop-yellow transition-all duration-300"
               />
               <span className="relative z-20 text-[10px] font-mono font-bold tracking-[0.3em] text-pop-black">
                {progress === 100 ? 'LOADER COMPLETE 100%' : `LOADING ${progress}%`}
               </span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
