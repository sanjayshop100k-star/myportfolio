import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const IMAGES = [
  'p (1).webp',
  'p (2).webp',
  'p (3).webp',
  'p (4).webp',
  'p (5).webp',
  'p (6).webp',
];

export const MediaStack: React.FC = () => {
  const [index, setIndex] = useState(2);

  const next = () => setIndex((prev) => (prev + 1) % IMAGES.length);
  const prev = () => setIndex((prev) => (prev - 1 + IMAGES.length) % IMAGES.length);

  return (
    <section className="py-32 bg-pop-white overflow-hidden">
      <div className="container mx-auto px-4 text-center mb-16">
        <h2 className="text-4xl md:text-6xl font-display font-black text-pop-black mb-4">
          SELECTED <span className="text-pop-red">WORKS</span>
        </h2>
        <p className="font-mono text-sm tracking-wider uppercase opacity-60">Hover or Swipe to interact</p>
      </div>

      <div className="relative h-[400px] md:h-[600px] flex items-center justify-center">
        <div className="relative w-[280px] h-[400px] md:w-[400px] md:h-[550px] perspective-1000">
          {IMAGES.map((img, i) => {
            const position = i - index;
            // Handle wrap around for relative positions
            let relativePosition = position;
            if (position > IMAGES.length / 2) relativePosition -= IMAGES.length;
            if (position < -IMAGES.length / 2) relativePosition += IMAGES.length;

            const isActive = relativePosition === 0;
            const opacity = isActive ? 1 : Math.max(0.4, 1 - Math.abs(relativePosition) * 0.3);
            const scale = isActive ? 1.1 : 1 - Math.abs(relativePosition) * 0.15;
            const zIndex = 10 - Math.abs(relativePosition);
            const x = relativePosition * (window.innerWidth < 768 ? 80 : 150);
            const rotateY = relativePosition * -15;

            return (
              <motion.div
                key={i}
                animate={{
                  x,
                  scale,
                  zIndex,
                  opacity,
                  rotateY,
                }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className={cn(
                  "absolute inset-0 cursor-pointer",
                  isActive ? "z-[100]" : "blur-[1px] pointer-events-none"
                )}
                onClick={() => setIndex(i)}
              >
                <div className="w-full h-full brutal-border pop-shadow bg-pop-black overflow-hidden relative group">
                  <img
                    src={img}
                    alt={`Work ${i}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  {isActive && (
                    <div className="absolute inset-x-0 bottom-0 p-6 bg-white border-t-4 border-pop-black">
                        <div className="font-display font-black text-pop-black text-lg uppercase">PROJECT 0{i + 1}</div>
                        <div className="text-pop-black/60 text-[10px] font-mono tracking-widest uppercase">POP-ART DIRECTION</div>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Navigation Buttons */}
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-4 md:px-24 z-50 pointer-events-none">
          <button 
            onClick={prev} 
            className="w-12 h-12 rounded-full bg-pop-black text-white flex items-center justify-center hover:bg-pop-red transition-colors pointer-events-auto"
          >
            <ChevronLeft size={24} />
          </button>
          <button 
            onClick={next} 
            className="w-12 h-12 rounded-full bg-pop-black text-white flex items-center justify-center hover:bg-pop-red transition-colors pointer-events-auto"
          >
            <ChevronRight size={24} />
          </button>
        </div>
      </div>
    </section>
  );
};
