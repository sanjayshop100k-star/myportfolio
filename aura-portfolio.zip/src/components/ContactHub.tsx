import React from 'react';
import { motion } from 'motion/react';
import { Phone, Mail, MessageCircle } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export const ContactHub: React.FC = () => {
  const contacts = [
    {
      icon: <MessageCircle size={24} />,
      label: 'WhatsApp',
      href: 'https://wa.me/919825980804',
      bg: 'bg-[#25D366]',
      color: 'text-white',
    },
    {
      icon: <Phone size={24} />,
      label: 'Phone',
      href: 'tel:+919825980804',
      bg: 'bg-pop-red',
      color: 'text-white',
    },
    {
      icon: <Mail size={24} />,
      label: 'Email',
      href: 'mailto:sanjaysahu18k@email.com',
      bg: 'bg-pop-black',
      color: 'text-white',
    }
  ];

  return (
    <div className="fixed bottom-8 left-8 right-8 z-[9999] flex justify-between items-center pointer-events-none">
      <div className="hidden md:flex bg-white brutal-border p-2 pop-shadow pointer-events-auto">
        <div className="bg-pop-black text-white px-4 py-1 text-xs font-black uppercase tracking-wider">
            Portfolio 2026 // AURA
        </div>
      </div>

      <div className="flex gap-4 pointer-events-auto">
        {contacts.map((contact, idx) => (
          <motion.a
            key={idx}
            href={contact.href}
            target="_blank"
            rel="noopener noreferrer"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 2 + idx * 0.1, type: 'spring' }}
            whileHover={{ scale: 1.1, translateY: -5 }}
            className={cn(
              "group relative h-14 px-6 rounded-full flex items-center justify-center brutal-border pop-shadow transition-all",
              contact.bg,
              contact.color
            )}
          >
            <div className="flex items-center gap-3">
                {contact.icon}
                <span className="text-xs font-black uppercase tracking-widest hidden sm:block">
                    {contact.label}
                </span>
            </div>
          </motion.a>
        ))}
      </div>
    </div>
  );
};
