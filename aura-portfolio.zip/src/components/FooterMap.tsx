import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, X, Navigation } from 'lucide-react';

export const FooterMap: React.FC = () => {
  const [showPopup, setShowPopup] = useState(false);

  // Stylized map embed (using the location provided)
  const mapUrl = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d118231.29410186937!2d72.35515324545564!3d22.174150531!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395ec18df13b2d13%3A0x6a0f4a4a1599e1a1!2sGujarat!5e0!3m2!1sen!2sin!4v1713652690000!5m2!1sen!2sin";

  return (
    <section className="relative w-full h-[600px] border-t-8 border-pop-black overflow-hidden bg-gray-200">
      <iframe
        src={mapUrl}
        width="100%"
        height="100%"
        style={{ border: 0, filter: 'grayscale(1) contrast(1.2)' }}
        allowFullScreen
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        className="absolute inset-0 grayscale"
      />

      {/* Pop-Art Overlay for the "Live" feel */}
      <div className="absolute inset-0 bg-pop-yellow/20 pointer-events-none" />

      {/* Custom Global Marker */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
        <motion.button
          whileHover={{ scale: 1.1, rotate: 3 }}
          onClick={() => setShowPopup(true)}
          className="relative group"
        >
          {/* Glowing pulse */}
          <div className="absolute inset-0 rounded-full bg-pop-black animate-ping opacity-20" />
          
          {/* Marker Content */}
          <div className="relative w-16 h-16 rounded-full brutal-border pop-shadow overflow-hidden flex items-center justify-center bg-white">
            <img 
              src="input_file_0.png" 
              alt="Creator" 
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
        </motion.button>
      </div>

      {/* Custom Info Window */}
      <AnimatePresence>
        {showPopup && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[calc(50%+100px)] z-30 w-[280px] bg-white brutal-border p-0 pop-shadow-lg"
          >
            <div className="flex bg-pop-black text-white p-2 justify-between items-center px-4">
                <span className="text-[10px] font-black uppercase tracking-widest">LIVE LOCATION</span>
                <button onClick={() => setShowPopup(false)}><X size={14} /></button>
            </div>
            
            <div className="p-4">
                <img 
                  src="input_file_0.png" 
                  className="w-full h-32 object-cover brutal-border mb-3" 
                  referrerPolicy="no-referrer"
                />
                <h3 className="font-display font-black text-lg mb-1 uppercase tracking-tight">Sanjay Sahu</h3>
                <p className="font-mono text-[10px] text-gray-500 mb-4 uppercase">Gujarat, India</p>
                <a 
                  href="https://maps.app.goo.gl/6pphZLkNqrTRz4zy7"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full py-3 bg-pop-black text-white font-display font-black text-xs hover:bg-pop-red transition-colors"
                >
                  <Navigation size={14} />
                  GET DIRECTIONS
                </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 0)', backgroundSize: '24px 24px' }} />
    </section>
  );
};
