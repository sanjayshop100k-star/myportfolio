import React, { useState, useEffect } from 'react';
import { Preloader } from './components/Preloader';
import { Hero } from './components/Hero';
import { MediaStack } from './components/MediaStack';
import { FooterMap } from './components/FooterMap';
import { ContactHub } from './components/ContactHub';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [loading, setLoading] = useState(true);

  return (
    <main className="relative min-h-screen bg-pop-white">
      <Preloader onComplete={() => setLoading(false)} />

      <AnimatePresence>
        {!loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            {/* Minimal Header */}
            <header className="fixed top-0 left-0 w-full p-8 flex justify-between items-center z-[100] mix-blend-difference invert pointer-events-none">
                <div className="font-display font-black text-2xl tracking-tighter">SANJAY // SAHU</div>
                <div className="hidden md:flex gap-8 font-mono text-[10px] tracking-widest uppercase">
                    <span>Portfolio 2026</span>
                    <span>Available for Projects</span>
                    <span>Est. India</span>
                </div>
            </header>

            <Hero />
            
            {/* Divider */}
            <div className="w-full h-24 bg-pop-black flex items-center overflow-hidden">
                <motion.div 
                    animate={{ x: [0, -1000] }}
                    transition={{ repeat: Infinity, duration: 15, ease: "linear" }}
                    className="flex whitespace-nowrap text-white font-display font-black text-2xl"
                >
                    &nbsp;ARTISTIC // MODERN // MINIMAL // POP-ART // ARTISTIC // MODERN // MINIMAL // POP-ART // ARTISTIC // MODERN // MINIMAL // POP-ART //
                </motion.div>
            </div>

            <MediaStack />
            
            <section className="py-32 bg-pop-yellow px-8 border-y-8 border-pop-black">
                <div className="max-w-4xl mx-auto space-y-12">
                    <h2 className="text-6xl md:text-9xl font-display font-black tracking-tighter leading-[0.8] uppercase text-pop-black">
                        Let's build <br/> <span className="text-pop-red italic">Aura</span>.
                    </h2>
                    <div className="flex flex-col md:flex-row gap-8 items-start">
                        <p className="text-xl md:text-2xl font-bold leading-tight text-pop-black max-w-xl uppercase">
                            I specialize in creating high-impact visual stories through cinematic editing and strategic art direction. Based in Gujarat, working globally.
                        </p>
                        <button className="bg-pop-black text-white px-8 py-4 font-display font-black text-xl brutal-border pop-shadow hover:bg-pop-red hover:translate-x-1 hover:-translate-y-1 transition-all uppercase italic">
                            Hire Him
                        </button>
                    </div>
                </div>
            </section>

            <FooterMap />
            <ContactHub />

            <footer className="py-24 bg-white flex flex-col items-center border-t-8 border-pop-black">
                <div className="text-[12px] font-black tracking-[0.3em] uppercase text-pop-black mb-6 text-center">
                    © 2026 SANJAY SAHU // PORTFOLIO V2
                </div>
                <div className="w-24 h-4 bg-pop-red brutal-border" />
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}

